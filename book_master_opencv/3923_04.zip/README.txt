Scripts are in the "cameo" folder.  Haar cascade files are in the "cameo/cascades" folder.

The managers.py script is unchanged since Chapter 2.

The filters.py script is unchanged since Chapter 3.